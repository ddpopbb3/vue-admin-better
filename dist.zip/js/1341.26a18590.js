"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["1341"], {
15674: (function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/left.1b194ee6d9da225d.jpg";

}),

}]);