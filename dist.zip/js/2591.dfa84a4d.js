/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-1-14 06:31:43
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["2591"], {
55762: (function (module) {
module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+CiAgPHBhdGggZmlsbD0ibm9uZSIgZD0iTTAgMGgyNHYyNEgweiIvPgogIDxwYXRoIGQ9Ik0xIDNoNGw3IDEyIDctMTJoNEwxMiAyMiAxIDN6bTguNjY3IDBMMTIgN2wyLjMzMy00aDQuMDM1TDEyIDE0IDUuNjMyIDNoNC4wMzV6Ii8+Cjwvc3ZnPgo=";

}),

}]);