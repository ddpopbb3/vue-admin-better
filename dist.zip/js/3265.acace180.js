/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2025-9-16 12:31:43
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["3265"], {
27064: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* ESM import */var echarts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28839);
/* ESM import */var vue_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36104);


/* ESM default export */ __webpack_exports__["default"] = (vue_echarts__WEBPACK_IMPORTED_MODULE_1__["default"]);

}),

}]);