/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-1-28 06:31:46
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6047"], {
48453: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(70653);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(64014);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".page-header{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);border-radius:12px;padding:30px;margin-bottom:24px;color:#fff;box-shadow:0 8px 32px rgba(102,126,234,.3)}.page-header .header-content{display:flex;justify-content:space-between;align-items:center}.page-header .header-content .header-left .page-title{font-size:2rem;font-weight:700;margin:0 0 8px 0;display:flex;align-items:center;gap:12px}.page-header .header-content .header-left .page-title .vab-icon{font-size:1.8rem}.page-header .header-content .header-left .page-description{font-size:1rem;opacity:.9;margin:0}.page-header .header-content .header-right{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600}.page-header .header-content .header-right .vab-icon{font-size:1.3rem}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
54414: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(70653);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(64014);
/* import */ var _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_3_rspack_core_1_7_4_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".permissions-container[data-v-653eb5da]{padding:20px;background:#f5f7fa;min-height:100vh}.permissions-container .permission-card .card-header[data-v-653eb5da]{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600;color:#2c3e50}.permissions-container .permission-card .card-header .vab-icon[data-v-653eb5da]{color:#667ae4}.permissions-container .permission-card .permission-content .permission-info[data-v-653eb5da]{margin-bottom:20px}.permissions-container .permission-card .permission-content .permission-info .info-text[data-v-653eb5da]{display:flex;align-items:center;gap:8px;color:#606266;font-size:.9rem;margin:0;padding:12px;background:#f8f9fa;border-radius:8px;border-left:4px solid #667eea}.permissions-container .permission-card .permission-content .permission-info .info-text .vab-icon[data-v-653eb5da]{color:#667eea}.permissions-container .permission-card .permission-content .permission-form[data-v-653eb5da]{margin-bottom:20px}.permissions-container .permission-card .permission-content .current-permissions h4[data-v-653eb5da]{margin:0 0 12px 0;color:#2c3e50;font-size:1rem}.permissions-container .permission-card .permission-content .current-permissions .permissions-display[data-v-653eb5da]{display:flex;flex-wrap:wrap;gap:8px}.permissions-container .permission-card .permission-content .current-permissions .permissions-display .permission-tag[data-v-653eb5da]{display:flex;align-items:center;gap:4px;padding:6px 12px;border-radius:20px;font-weight:500}.permissions-container .permission-card .permission-content .current-permissions .permissions-display .permission-tag .vab-icon[data-v-653eb5da]{font-size:.8rem}.permissions-container .permission-card .button-demo .demo-section h4[data-v-653eb5da]{margin:0 0 16px 0;color:#2c3e50;font-size:1rem}.permissions-container .permission-card .button-demo .demo-section .button-group[data-v-653eb5da]{display:flex;flex-wrap:wrap;gap:12px}.permissions-container .permission-card .route-demo .demo-info[data-v-653eb5da]{margin-bottom:20px}.permissions-container .permission-card .route-demo .demo-info .info-text[data-v-653eb5da]{display:flex;align-items:flex-start;gap:8px;color:#606266;font-size:.9rem;margin:0 0 8px 0;line-height:1.5}.permissions-container .permission-card .route-demo .demo-info .info-text .vab-icon[data-v-653eb5da]{color:#667eea;margin-top:2px;flex-shrink:0}.permissions-container .permission-card .route-demo .route-table-container h4[data-v-653eb5da]{margin:0 0 16px 0;color:#2c3e50;font-size:1rem}.permissions-container .permission-card .route-demo .route-table-container .route-table[data-v-653eb5da]{border-radius:8px;overflow:hidden}.permissions-container .permission-card .route-demo .route-table-container .route-table .route-name[data-v-653eb5da]{display:flex;align-items:center;gap:6px;font-weight:500}.permissions-container .permission-card .route-demo .route-table-container .route-table .route-name .vab-icon[data-v-653eb5da]{color:#667eea}.permissions-container .permission-card .route-demo .route-table-container .route-table .route-icon[data-v-653eb5da]{color:#667eea;font-size:1rem}.permissions-container .permission-card .route-demo .route-table-container .route-table .route-badge[data-v-653eb5da]  .el-badge__content{background:#667eea}@media(max-width: 768px){.permissions-container[data-v-653eb5da]{padding:16px}.permissions-container .permission-card .button-demo .button-group[data-v-653eb5da]{flex-direction:column}}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
29425: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VabPageHeader; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=template&id=2b14fb2d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-header",class:_vm.customClass},[_c('div',{staticClass:"header-content"},[_c('div',{staticClass:"header-left"},[_c('h1',{staticClass:"page-title"},[(_vm.icon)?_c('vab-icon',{attrs:{"icon":_vm.icon}}):_vm._e(),_vm._v("\n        "+_vm._s(_vm.title)+"\n      ")],1),(_vm.description)?_c('p',{staticClass:"page-description",domProps:{"innerHTML":_vm._s(_vm.description)}}):_vm._e()]),(_vm.rightIcon || _vm.rightText)?_c('div',{staticClass:"header-right"},[_vm._t("right",function(){return [(_vm.rightIcon)?_c('vab-icon',{attrs:{"icon":_vm.rightIcon}}):_vm._e(),(_vm.rightText)?_c('span',[_vm._v(_vm._s(_vm.rightText))]):_vm._e()]})],2):_vm._e()])])}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.28.6_webpack@5.104.1/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* export default */ var VabPageHeadervue_type_script_lang_js_ = ({
  name: 'VabPageHeader',
  props: {
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: ''
    },
    icon: {
      type: Array,
      default: () => []
    },
    rightIcon: {
      type: Array,
      default: () => []
    },
    rightText: {
      type: String,
      default: ''
    },
    customClass: {
      type: String,
      default: ''
    }
  }
});
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
 /* export default */ var components_VabPageHeadervue_type_script_lang_js_ = (VabPageHeadervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64812);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(27381);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(51511);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(12932);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(7296);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(32077);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.4_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&
var VabPageHeadervue_type_style_index_0_lang_scss_ = __webpack_require__(48453);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.4_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VabPageHeadervue_type_style_index_0_lang_scss_["default"], options);




       /* export default */ var components_VabPageHeadervue_type_style_index_0_lang_scss_ = (VabPageHeadervue_type_style_index_0_lang_scss_["default"] && VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals ? VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(84011);
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VabPageHeadervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var VabPageHeader = (component.exports);

}),
28146: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ permissions; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/permissions/index.vue?vue&type=template&id=653eb5da&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"permissions-container"},[_c('vab-page-header',{attrs:{"description":"管理系统权限配置和用户角色分配","icon":['fas', 'shield-alt'],"right-icon":['fas', 'user-circle'],"right-text":("当前用户: " + _vm.username),"title":"权限管理"}}),_c('el-card',{staticClass:"permission-card",attrs:{"shadow":"hover"}},[_c('div',{staticClass:"card-header",attrs:{"slot":"header"},slot:"header"},[_c('vab-icon',{attrs:{"icon":['fas', 'exchange-alt']}}),_c('span',[_vm._v("权限切换")])],1),_c('div',{staticClass:"permission-content"},[_c('div',{staticClass:"permission-info"},[_c('p',{staticClass:"info-text"},[_c('vab-icon',{attrs:{"icon":['fas', 'info-circle']}}),_vm._v("\n          intelligence模式：前端根据permissions拦截路由（演示环境默认使用此方案）\n        ")],1)]),_c('el-form',{ref:"form",staticClass:"permission-form",attrs:{"inline":true,"model":_vm.form}},[_c('el-form-item',{staticClass:"account-selector",attrs:{"label":"切换账号"}},[_c('el-radio-group',{staticClass:"account-radio-group",model:{value:(_vm.form.account),callback:function ($$v) {_vm.$set(_vm.form, "account", $$v)},expression:"form.account"}},[_c('el-radio-button',{staticClass:"account-radio",attrs:{"label":"admin"}},[_c('vab-icon',{attrs:{"icon":['fas', 'crown']}}),_c('span',[_vm._v("管理员")])],1),_c('el-radio-button',{staticClass:"account-radio",attrs:{"label":"editor"}},[_c('vab-icon',{attrs:{"icon":['fas', 'edit']}}),_c('span',[_vm._v("编辑者")])],1),_c('el-radio-button',{staticClass:"account-radio",attrs:{"label":"test"}},[_c('vab-icon',{attrs:{"icon":['fas', 'user']}}),_c('span',[_vm._v("测试员")])],1)],1)],1),_c('el-form-item',[_c('el-button',{staticClass:"change-btn",attrs:{"type":"primary"},on:{"click":_vm.handleChangePermission}},[_c('vab-icon',{attrs:{"icon":['fas', 'sync-alt']}}),_vm._v("\n            切换权限\n          ")],1)],1)],1),_c('div',{staticClass:"current-permissions"},[_c('h4',[_vm._v("当前账号拥有的权限：")]),_c('div',{staticClass:"permissions-display"},_vm._l((_vm.permissions),function(permission){return _c('el-tag',{key:permission,staticClass:"permission-tag",attrs:{"type":_vm.getPermissionTagType(permission)}},[_c('vab-icon',{attrs:{"icon":_vm.getPermissionIcon(permission)}}),_vm._v("\n            "+_vm._s(permission)+"\n          ")],1)}),1)])],1)]),_c('el-card',{staticClass:"permission-card",attrs:{"shadow":"hover"}},[_c('div',{staticClass:"card-header",attrs:{"slot":"header"},slot:"header"},[_c('vab-icon',{attrs:{"icon":['fas', 'mouse-pointer']}}),_c('span',[_vm._v("按钮级权限演示")])],1),_c('div',{staticClass:"button-demo"},[_c('div',{staticClass:"demo-section"},[_c('h4',[_vm._v("权限按钮展示：")]),_c('div',{staticClass:"button-group"},[_c('el-button',{directives:[{name:"permissions",rawName:"v-permissions",value:(['admin']),expression:"['admin']"}],staticClass:"demo-btn",attrs:{"type":"primary"}},[_c('vab-icon',{attrs:{"icon":['fas', 'crown']}}),_vm._v("\n            我是拥有[\"admin\"]权限的按钮\n          ")],1),_c('el-button',{directives:[{name:"permissions",rawName:"v-permissions",value:(['editor']),expression:"['editor']"}],staticClass:"demo-btn",attrs:{"type":"success"}},[_c('vab-icon',{attrs:{"icon":['fas', 'edit']}}),_vm._v("\n            我是拥有[\"editor\"]权限的按钮\n          ")],1),_c('el-button',{directives:[{name:"permissions",rawName:"v-permissions",value:(['test']),expression:"['test']"}],staticClass:"demo-btn",attrs:{"type":"warning"}},[_c('vab-icon',{attrs:{"icon":['fas', 'user']}}),_vm._v("\n            我是拥有[\"test\"]权限的按钮\n          ")],1)],1)])])]),_c('el-card',{staticClass:"permission-card",attrs:{"shadow":"hover"}},[_c('div',{staticClass:"card-header",attrs:{"slot":"header"},slot:"header"},[_c('vab-icon',{attrs:{"icon":['fas', 'route']}}),_c('span',[_vm._v("路由权限演示")])],1),_c('div',{staticClass:"route-demo"},[_c('div',{staticClass:"demo-info"},[_c('p',{staticClass:"info-text"},[_c('vab-icon',{attrs:{"icon":['fas', 'info-circle']}}),_vm._v("\n          all模式：路由以及view文件引入全部交给后端（权限复杂，且随时变更，建议使用此方案）\n        ")],1),_c('p',{staticClass:"info-text"},[_vm._v("\n          settings.js配置authentication为all即可完全交由后端控制，mock中有后端接口示例，权限繁琐，有几十种权限的项目直接用这种。\n        ")])]),_c('div',{staticClass:"route-table-container"},[_c('h4',[_vm._v("路由配置表：")]),_c('el-table',{staticClass:"route-table",attrs:{"border":"","data":_vm.tableData,"default-expand-all":"","highlight-current-row":"","row-key":"path","stripe":"","tree-props":{ children: 'children', hasChildren: 'hasChildren' }}},[_c('el-table-column',{attrs:{"label":"路由名称","prop":"name","show-overflow-tooltip":"","width":"150"},scopedSlots:_vm._u([{key:"default",fn:function(ref){
var row = ref.row;
return [_c('div',{staticClass:"route-name"},[(row.meta && row.meta.icon)?_c('vab-icon',{attrs:{"icon":['fas', row.meta.icon]}}):_vm._e(),_c('span',[_vm._v(_vm._s(row.name))])],1)]}}])}),_c('el-table-column',{attrs:{"label":"路径","prop":"path","show-overflow-tooltip":"","width":"200"}}),_c('el-table-column',{attrs:{"label":"组件","prop":"component","show-overflow-tooltip":"","width":"150"}}),_c('el-table-column',{attrs:{"label":"重定向","prop":"redirect","show-overflow-tooltip":"","width":"150"}}),_c('el-table-column',{attrs:{"label":"标题","prop":"meta.title","show-overflow-tooltip":"","width":"120"}}),_c('el-table-column',{attrs:{"label":"图标","show-overflow-tooltip":"","width":"80"},scopedSlots:_vm._u([{key:"default",fn:function(ref){
var row = ref.row;
return [(row.meta && row.meta.icon)?_c('span',[_c('vab-icon',{staticClass:"route-icon",attrs:{"icon":['fas', row.meta.icon]}})],1):_vm._e()]}}])}),_c('el-table-column',{attrs:{"label":"固定","show-overflow-tooltip":"","width":"80"},scopedSlots:_vm._u([{key:"default",fn:function(ref){
var row = ref.row;
return [(row.meta && row.meta.affix)?_c('el-tag',{attrs:{"size":"mini","type":"success"}},[_vm._v("是")]):_c('el-tag',{attrs:{"size":"mini","type":"info"}},[_vm._v("否")])]}}])}),_c('el-table-column',{attrs:{"label":"无缓存","show-overflow-tooltip":"","width":"80"},scopedSlots:_vm._u([{key:"default",fn:function(ref){
var row = ref.row;
return [(row.meta && row.meta.noKeepAlive)?_c('el-tag',{attrs:{"size":"mini","type":"warning"}},[_vm._v("是")]):_c('el-tag',{attrs:{"size":"mini","type":"info"}},[_vm._v("否")])]}}])}),_c('el-table-column',{attrs:{"label":"徽章","show-overflow-tooltip":"","width":"80"},scopedSlots:_vm._u([{key:"default",fn:function(ref){
var row = ref.row;
return [(row.meta && row.meta.badge)?_c('el-badge',{staticClass:"route-badge",attrs:{"value":row.meta.badge}}):_c('span',[_vm._v("-")])]}}])})],1)],1)])])],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./node_modules/.pnpm/vuex@3.6.2_vue@2.7.16/node_modules/vuex/dist/vuex.esm.js
var vuex_esm = __webpack_require__(50651);
// EXTERNAL MODULE: ./src/config/index.js
var config = __webpack_require__(96133);
// EXTERNAL MODULE: ./src/api/router.js
var router = __webpack_require__(15164);
// EXTERNAL MODULE: ./src/components/VabPageHeader/index.vue + 5 modules
var VabPageHeader = __webpack_require__(29425);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.28.6_webpack@5.104.1/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/permissions/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* export default */ var permissionsvue_type_script_lang_js_ = ({
  name: 'Permissions',
  components: {
    VabPageHeader: VabPageHeader["default"]
  },
  data() {
    return {
      form: {
        account: ''
      },
      tableData: [],
      res: []
    };
  },
  computed: {
    ...(0,vuex_esm.mapGetters)({
      username: 'user/username',
      permissions: 'user/permissions'
    })
  },
  created() {
    this.fetchData();
  },
  mounted() {
    this.form.account = this.username;
  },
  methods: {
    handleChangePermission() {
      this.$confirm('确定要切换权限吗？切换后页面将重新加载。', '权限切换', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        localStorage.setItem(config.tokenTableName, `${this.form.account}-accessToken`);
        this.$message.success('权限切换成功，页面即将重新加载...');
        setTimeout(() => {
          location.reload();
        }, 1000);
      }).catch(() => {
        this.$message.info('已取消权限切换');
      });
    },
    async fetchData() {
      const res = await (0,router.getRouterList)();
      this.tableData = res.data;
      this.res = res;
    },
    getPermissionTagType(permission) {
      const types = {
        admin: 'danger',
        editor: 'warning',
        test: 'info'
      };
      return types[permission] || 'info';
    },
    getPermissionIcon(permission) {
      const icons = {
        admin: 'crown',
        editor: 'edit',
        test: 'user'
      };
      return ['fas', icons[permission] || 'user'];
    }
  }
});
;// CONCATENATED MODULE: ./src/views/vab/permissions/index.vue?vue&type=script&lang=js&
 /* export default */ var vab_permissionsvue_type_script_lang_js_ = (permissionsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64812);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(27381);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(51511);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(12932);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(7296);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(32077);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.4_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/permissions/index.vue?vue&type=style&index=0&id=653eb5da&lang=scss&scoped=true&
var permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_ = __webpack_require__(54414);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.3_@rspack+core@1.7.4_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/vab/permissions/index.vue?vue&type=style&index=0&id=653eb5da&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_["default"], options);




       /* export default */ var vab_permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_ = (permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_["default"] && permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_["default"].locals ? permissionsvue_type_style_index_0_id_653eb5da_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/vab/permissions/index.vue?vue&type=style&index=0&id=653eb5da&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.27_css-loader@7.1.3_@rspack+core@1.7.4_webpack@_0e6180003fa7883e6829bd0864a631ef/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(84011);
;// CONCATENATED MODULE: ./src/views/vab/permissions/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  vab_permissionsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "653eb5da",
  null
  
)

/* export default */ var permissions = (component.exports);

}),

}]);