"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["1514"], {
14845: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* ESM import */var echarts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76469);
/* ESM import */var vue_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22273);


/* ESM default export */ __webpack_exports__["default"] = (vue_echarts__WEBPACK_IMPORTED_MODULE_1__["default"]);

}),

}]);