/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-4-7 12:31:43
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["2313"], {
36560: (function (module, __unused_rspack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/right.9d354013c83fa357.jpg";

}),

}]);